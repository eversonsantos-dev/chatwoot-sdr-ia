# Release v1.2.0 - IA Conversacional com OpenAI Tempo Real ⭐

**Data**: 20/11/2025
**Commits**: `d6fd50e`, `de76ea7`, `ddd9465`, `69beff2`
**Tag**: `v1.2.0`
**Imagem Docker**: `localhost/chatwoot-sdr-ia:ddd9465`

## ✅ VERSÃO TESTADA E FUNCIONAL EM PRODUÇÃO

Esta é a versão **RECOMENDADA** para produção com comportamento 100% conversacional e natural.

[Conteúdo completo disponível em /root/chatwoot-sdr-ia/]
